# TERRA · Carbon Intelligence Platform
## v1.0.0 · Production Build

---

## Quick Start (Local)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run
streamlit run terra_app.py

# 3. Open browser at http://localhost:8501
# Demo login: demo@terra-carbon.io / Terra2025Demo!
```

---

## Project Structure

```
terra_app.py          Main entry point + all page renderers
terra/
  __init__.py
  auth.py             bcrypt authentication (login, register, change password)
  db.py               SQLite database (parameterised queries, GDPR-compliant)
  engine.py           Carbon calculation engine (IPCC AR6 + IEA 2023 factors)
  security.py         Input sanitisation, rate limiting, password policy
  policy.py           Terms of Service + Privacy Policy (full legal text)
  reports.py          PDF report generator (fpdf2)
  ui.py               Shared Streamlit UI components + CSS
requirements.txt      Python dependencies
```

---

## Deploy to Streamlit Cloud (Free)

1. Push to a GitHub repo
2. Go to https://share.streamlit.io
3. Connect repo → set main file: `terra_app.py`
4. Add secrets in Streamlit Cloud dashboard:
   ```
   TERRA_DB_PATH = "/mount/src/terra_data.db"
   ```
5. Deploy — your URL will be `https://yourapp.streamlit.app`

---

## Deploy to Production (VPS / Railway / Render)

### Environment variables
```bash
TERRA_DB_PATH=/var/terra/production.db   # SQLite path
```

### For PostgreSQL (recommended for production):
Swap `sqlite3` in `terra/db.py` for `psycopg2`:
```bash
pip install psycopg2-binary
DATABASE_URL=postgresql://user:pass@host:5432/terra
```

### Run with gunicorn (optional):
```bash
streamlit run terra_app.py --server.port 8080 --server.address 0.0.0.0
```

---

## Security Features

| Feature | Implementation |
|---------|---------------|
| Password hashing | bcrypt, cost factor 12 |
| SQL injection | Parameterised queries throughout |
| XSS prevention | html.escape() on all user inputs |
| Rate limiting | 5 attempts → 5-minute lockout |
| Password policy | Min 8 chars · 1 number · 1 symbol |
| Clickjacking | X-Frame-Options via JS guard |
| Audit logging | All auth events logged with timestamp |
| GDPR / KDPA | Full data export, erasure, consent records |
| Policy agreement | Checkbox consent gated at registration |
| Session security | Streamlit encrypted session state |
| PII protection | Password hash never returned in queries |

---

## Revenue Model

| Tier | Price | Target |
|------|-------|--------|
| Starter | $49/month | NGOs, small biz |
| Business | $149/month | SMEs (most popular) |
| Enterprise | $299/month | Corporates, government |

Additional revenue:
- Carbon credit marketplace commission (2–5%)
- White-label licensing ($2,000–$10,000/month)
- API access for ESG data integrations
- Government contracts for national carbon reporting

---

## Compliance Frameworks Supported
- GRI Standards
- TCFD (Task Force on Climate-related Financial Disclosures)
- CSRD (EU Corporate Sustainability Reporting Directive)
- GHG Protocol Corporate Standard
- Kenya Carbon Markets Act 2023

---

## Contact
- General: hello@terra-carbon.io
- Support: support@terra-carbon.io
- Security: security@terra-carbon.io
- Privacy: privacy@terra-carbon.io

© 2025 Terra Climate Technologies Ltd · Nairobi, Kenya
